﻿namespace BashSoft
{
    using IO;

    public class Launcher
    {
        public static void Main(string[] args)
        {
            InputReader.StartReadingCommands();
        }
    }
}